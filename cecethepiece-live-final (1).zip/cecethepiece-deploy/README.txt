# cecethepiece Business Hub — Deployment Guide
### 5 partners · 5 locations · 1 shared live database

---

## What you need (all free)
- Your existing **Supabase** account → supabase.com
- A **Netlify** account (free) → netlify.com
- This folder (2 files: index.html + SUPABASE_SETUP.sql)

---

## STEP 1 — Set up the database (Supabase) — 5 minutes

1. Go to **https://supabase.com/dashboard**
2. Open your project (or create a new one named "cecethepiece")
3. Click **SQL Editor** → **New query**
4. Open `SUPABASE_SETUP.sql` from this folder, **copy all of it**, paste it in, click **RUN**
5. You'll see all 8 tables created + the 5 partner slots pre-added
6. **Edit the partner names** — go to Table Editor → team_members and update
   Partner2, Partner3, Partner4, Partner5 to your real names

---

## STEP 2 — Get your Supabase keys

1. In your Supabase project: **Settings → API**
2. Copy these two values:
   - **Project URL** — looks like: `https://abcxyzabc.supabase.co`
   - **anon public** key — the long one (starts with `eyJ...`)

---

## STEP 3 — Add your keys to the app

1. Open `index.html` in any text editor
   (Notepad on Windows, TextEdit on Mac, or VS Code)
2. Find these two lines near the top of the `<script>` section:
   ```
   const SUPABASE_URL = 'YOUR_SUPABASE_URL';
   const SUPABASE_KEY = 'YOUR_SUPABASE_ANON_KEY';
   ```
3. Replace both values with what you copied in Step 2:
   ```
   const SUPABASE_URL = 'https://abcxyzabc.supabase.co';
   const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5...';
   ```
4. Save the file

---

## STEP 4 — Host it live on Netlify (free, 2 minutes)

### Option A: Drag & Drop (easiest)
1. Go to **https://app.netlify.com**
2. Sign up free (use GitHub or email)
3. On the dashboard, you'll see a box that says
   **"Drag and drop your site folder here"**
4. Drag the **entire cecethepiece-deploy folder** onto that box
5. Wait 10 seconds — Netlify gives you a live URL like:
   `https://cheerful-mango-abc123.netlify.app`
6. **That's your app URL.** Share it with all 5 partners.

### Option B: Custom URL (optional, $0–12/yr)
1. In Netlify: **Site settings → Domain management → Add custom domain**
2. Buy a domain like `hub.cecethepiece.com` from Namecheap (~$12/yr)
3. Follow Netlify's DNS setup (5 minutes, they walk you through it)

---

## STEP 5 — Share with your 5 partners

Send each partner this message:

> Hey! Our business hub is live at: [YOUR NETLIFY URL]
> Open it in Chrome on your phone or computer.
> When it loads, tap your name, then go to **Connections** to add your
> own Instagram and Facebook tokens. Everything else (pieces, contacts,
> sales) is already shared.

---

## What each partner does on first login

1. Open the app URL
2. Tap their name (or type it to add themselves)
3. Go to **Connections** → add their personal Instagram / Facebook tokens
4. Go to **Social Media → ⚙️ Auto-Schedule** → turn on auto-post, set times
5. Go to **Contacts & CRM → 🔍 Find Prospects** → generate their first 10 leads
6. Go to **Contacts & CRM → 📬 Today's Outreach** → start hitting their 5/day

---

## What's shared vs. personal

| Data | All 5 partners see it |
|---|---|
| Art collection / pieces | ✅ Shared |
| Contacts & CRM | ✅ Shared |
| Stripe / Shopify / Mailchimp | ✅ Shared |
| Sales stats | ✅ Shared |
| Instagram account | 🔒 Personal per partner |
| Facebook Page | 🔒 Personal per partner |
| TikTok account | 🔒 Personal per partner |
| Post queue & schedule | 🔒 Personal per partner |

---

## Updating the app later

When you get a new version of index.html:
1. Go to Netlify → your site → **Deploys**
2. Drag the new index.html onto the deploy drop zone
3. Done — live in 10 seconds, all partners get the update automatically

---

## Troubleshooting

**"Database error" on load:**
→ Double-check you pasted the Supabase URL and key correctly (no extra spaces)

**"Cannot read properties of undefined":**
→ Make sure you ran the full SQL setup file in Supabase

**Partner can't see their name:**
→ Go to Supabase → Table Editor → team_members → add their name manually

**Social posts not auto-posting:**
→ Each partner needs to add their own token in Connections
→ The page must stay open (or a team member's browser must stay open) for the checker to fire

---

## Need to make changes to the app?

Go back to Claude and say "update cecethepiece" — upload the current index.html
and describe what you want changed. Claude will send you a new index.html.
Just drag it onto Netlify to redeploy.
