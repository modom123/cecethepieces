-- ════════════════════════════════════════════════════════════
--  cecethepiece Business Hub — Supabase Database Setup
--  Run this ENTIRE file in: Supabase → SQL Editor → New query
-- ════════════════════════════════════════════════════════════

-- ── 1. PIECES (shared across all 5 partners) ─────────────────
create table if not exists pieces (
  id           uuid primary key default gen_random_uuid(),
  created_at   timestamptz default now(),
  title        text not null,
  type         text,
  price        text,
  status       text default 'available',
  image        text,
  dimensions   text,
  materials    text,
  description  text,
  caption      text,
  date         text,
  payment_link text
);
alter table pieces enable row level security;
drop policy if exists "Public access" on pieces;
create policy "Public access" on pieces for all using (true) with check (true);

-- ── 2. CONTACTS / CRM (shared) ───────────────────────────────
create table if not exists contacts (
  id          uuid primary key default gen_random_uuid(),
  created_at  timestamptz default now(),
  name        text not null,
  type        text,
  email       text,
  phone       text,
  heat        text default 'warm',
  source      text,
  notes       text,
  last_out    text default '—'
);
alter table contacts enable row level security;
drop policy if exists "Public access" on contacts;
create policy "Public access" on contacts for all using (true) with check (true);

-- ── 3. SHARED SETTINGS (Stripe, Shopify, Mailchimp keys) ─────
create table if not exists settings (
  id   text primary key,
  data jsonb
);
alter table settings enable row level security;
drop policy if exists "Public access" on settings;
create policy "Public access" on settings for all using (true) with check (true);

-- ── 4. TEAM MEMBERS (the 5 partners) ─────────────────────────
create table if not exists team_members (
  id          uuid primary key default gen_random_uuid(),
  created_at  timestamptz default now(),
  name        text not null unique,
  color       text default '#d4820a',
  avatar      text
);
alter table team_members enable row level security;
drop policy if exists "Public access" on team_members;
create policy "Public access" on team_members for all using (true) with check (true);

-- ── 5. PER-USER SOCIAL TOKENS (each partner's own IG/FB/TT) ──
create table if not exists user_social_keys (
  id       uuid primary key default gen_random_uuid(),
  user_id  uuid references team_members(id) on delete cascade unique,
  data     jsonb
);
alter table user_social_keys enable row level security;
drop policy if exists "Public access" on user_social_keys;
create policy "Public access" on user_social_keys for all using (true) with check (true);

-- ── 6. PER-USER SOCIAL SCHEDULE (each partner's own schedule) ─
create table if not exists user_social_settings (
  id       uuid primary key default gen_random_uuid(),
  user_id  uuid references team_members(id) on delete cascade unique,
  data     jsonb
);
alter table user_social_settings enable row level security;
drop policy if exists "Public access" on user_social_settings;
create policy "Public access" on user_social_settings for all using (true) with check (true);

-- ── 7. POST QUEUE (per partner, their own social posts) ───────
create table if not exists post_queue (
  id           uuid primary key default gen_random_uuid(),
  created_at   timestamptz default now(),
  title        text,
  caption      text,
  platforms    text[],
  post_type    text,
  scheduled_at timestamptz,
  posted_at    timestamptz,
  status       text default 'pending',
  piece_id     uuid references pieces(id) on delete set null,
  image        text,
  user_id      uuid references team_members(id) on delete set null,
  user_name    text
);
alter table post_queue enable row level security;
drop policy if exists "Public access" on post_queue;
create policy "Public access" on post_queue for all using (true) with check (true);

-- ── 8. SEED: Pre-create the 5 partner slots ──────────────────
-- Edit these names to match your actual 5 partners before running
insert into team_members (name, color, avatar) values
  ('Cece',    '#d4820a', 'C'),
  ('Partner2','#0a9688', 'P'),
  ('Partner3','#6b3fa0', 'P'),
  ('Partner4','#e03a2f', 'P'),
  ('Partner5','#1e8c4e', 'P')
on conflict (name) do nothing;

-- ✅ Done! All 8 tables created. Go back to the app and refresh.
-- Next step: paste your Supabase URL + anon key into index.html
